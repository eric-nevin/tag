var mongoose = require('mongoose');
var Chat = mongoose.model('Chat');

module.exports = (function() {
	return {
		create: function(req, res) {

		},
		update: function(req, res) {
		
		}
	}
})();

