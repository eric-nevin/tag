var actions = require('./../controllers/actions.js');



  module.exports = function(app) {
   
   app.post('/create', function(req, res) {
        actions.create(req, res);
    })
    app.post('/update', function(req, res) {
        actions.update(req, res);
    })

  };